import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import '../Screens/setting.dart';
import '../Screens/Dashboard.dart';

class Notifications extends StatefulWidget {
  final String email;

  Notifications({required this.email});

  @override
  State<Notifications> createState() => _NotificationsState();
}

class _NotificationsState extends State<Notifications> {
  int _selectedIndex = 1;

  CalendarFormat _calendarFormat = CalendarFormat.month;
  DateTime _focusedDay = DateTime.now();

  List<DateTime> _nationalHolidays = [
    // Define your list of national holidays here
    DateTime.utc(2024, 5, 1), // Example: May 1st, 2024
    DateTime.utc(2024, 7, 4), // Example: July 4th, 2024
    // Add more holidays as needed
  ];

  bool _isNationalHoliday(DateTime day) {
    // Check if the given day is a national holiday
    return _nationalHolidays.contains(day);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(90, 19, 175, 239),
        title: Text(
          'Notifications',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            icon: Icon(
              Icons.account_circle,
              size: 40,
            ),
            onPressed: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => Setting(email: widget.email)),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          TableCalendar(
            calendarFormat: _calendarFormat,
            focusedDay: _focusedDay,
            firstDay: DateTime.utc(2022, 1, 1),
            lastDay: DateTime.utc(2030, 12, 31),
            headerStyle: HeaderStyle(
              formatButtonVisible: false,
            ),
            calendarStyle: CalendarStyle(
              weekendTextStyle: TextStyle(color: Colors.red),
              holidayTextStyle: TextStyle(color: Colors.blue),
            ),
            holidayPredicate: _isNationalHoliday, // Show national holidays
            onFormatChanged: (format) {
              setState(() {
                _calendarFormat = format;
              });
            },
            onPageChanged: (focusedDay) {
              _focusedDay = focusedDay;
            },
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        // Set background color to white
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard),
            label: 'Dashboard',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_month),
            label: 'Calendar',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Settings',
          ),
        ],
        currentIndex: _selectedIndex, // Current selected index
        selectedItemColor: Colors.blueAccent, // Color for selected tab
        unselectedItemColor: Colors.grey, // Color for unselected tab
        onTap: (index) {
          setState(() {
            _selectedIndex = index; // Update selected index
          });
          switch (index) {
            case 0:
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Dashboard(email: widget.email)),
              );
              break;
            case 1:
            // No need to navigate to Notifications again
              break;
            case 2:
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Setting(email: widget.email)),
              );
              break;
            default:
              break;
          }
        },
      ),
    );
  }
}
