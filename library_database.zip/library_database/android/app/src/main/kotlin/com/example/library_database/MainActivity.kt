package com.example.library_database

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
